"use strict";

function toggle_phone_list(e, i) {
  var o = $(e).closest(".wrapper-phone");i ? (o.find(".phone-list").hide("fast"), o.find(".show-all-phone-text").show("fast"), o.find(".show-all-phone .icon-item").show("fast")) : (o.find(".show-all-phone-text").hide("fast"), o.find(".show-all-phone .icon-item").hide("fast"), o.find(".phone-list").show("fast")), o.find(".show-all-phone-link").text(i ? "показать всё" : "скрыть всё");
}var toClickPhone = !1;$(".show-all-phone-link, .show-all-phones").on("click", function () {
  return toClickPhone ? (toggle_phone_list($(this), !0), toClickPhone = !1) : ($(window).width() <= 768 && ($(".location-text").slideUp("fast"), toClickLocation = !1), toggle_phone_list($(this)), toClickPhone = !0), !1;
});var toClickLocation = !1;$(".location-icon").on("click", ".icon-location", function () {
  $(window).width() <= 768 && (toClickLocation ? ($(".location-text").slideUp("fast"), toClickLocation = !1) : (toggle_phone_list(!0), toClickPhone = !1, $(".location-text").slideDown("fast"), toClickLocation = !0));
}), $(".menu-item").on("click", function () {
  $(".menu-item-active").removeClass("menu-item-active"), $(this).addClass("menu-item-active");
}), $(".mobile-menu").on("click", function () {
  $(".mobile-menu-pic").hasClass("icon-mobile-menu-open") ? ($(".mobile-menu-pic").removeClass("icon-mobile-menu-open"), $(".mobile-menu-pic").addClass("icon-cancel"), $(".mobile-menu__list").slideDown("fast")) : ($(".mobile-menu-pic").removeClass("icon-cancel"), $(".mobile-menu-pic").addClass("icon-mobile-menu-open"), $(".mobile-menu__list").slideUp("fast"));
}), $(".mobile-menu__link").bind("click", function () {
  $(this).parent().find(".mobile-submenu__list").slideToggle("fast"), $(".mobile-submenu__item").hasClass("is-expanded") && ($(this).parent().find(".mobile-submenu-catalog-list").slideUp("fast"), $(".mobile-submenu__item").removeClass("is-expanded")), $(this).parent().toggleClass("is-expanded"), $(this).toggleClass("is-active");
}), $(".mobile-submenu__link").bind("click", function () {
  $(this).next(".mobile-submenu__catalog-list").toggleClass("active");
}), $(document).ready(function () {
  $(".js-dropp-action").click(function (e) {
    e.preventDefault(), $(this).toggleClass("js-open"), $(this).parent().next(".dropp-body").toggleClass("js-open");
  }), $(".dropp-body label").click(function () {
    $(this).addClass("js-open").siblings().removeClass("js-open"), $(".dropp-body,.js-dropp-action").removeClass("js-open");
  }), $('input[name="dropp"]').change(function () {
    var e = $("input[name='dropp']:checked").val();$(".js-value").text(e.toUpperCase());
  });
}), $(".left-navigation-link").bind("click", function (e) {
  $("body").hasClass("products-page") && ($(this).parent().find(".left-subnavigation-list").slideToggle("fast"), $(this).parent().toggleClass("is-expanded"), $(this).toggleClass("is-active"), e.preventDefault());
}), $(document).on("click", ".modal-fade-screen, .modal-close, .call", function () {
  $(".modal-state:checked").prop("checked", !1).change();
}), $(function (e) {
  e(".number-phone").mask("(999)999-99-99");
}), $(".basket").on("click", function () {
  $(".basket-list").slideToggle("fast");
}), $(document).on("click", ".close_modal_prod", function () {
  $(this).closest(".modal-window").hide();
}), $(".add-to-cart").click(function () {
  $("#modal-add-product").closest(".modal-window").show();
});var callbackBTN = document.querySelector(".js-callback-trigger");callbackBTN && callbackBTN.addEventListener("click", function () {
  callBack.showDialog();
});var callBack = new Vue({ el: "#dialog-callback", data: { show: "", ok: !1, formFields: { name: "", email: "", phone: "" }, errorFields: { name: "", email: "", phone: "" } }, methods: { resetField: function resetField(e) {
      for (var i in e) {
        this.formFields.hasOwnProperty(i) && (this.formFields[i] = "");
      }
    }, showDialog: function showDialog() {
      this.show = "show";
    }, closeDialog: function closeDialog() {
      this.show = "", this.resetField(this.formFields), this.resetField(this.errorFields);
    }, postRequest: function postRequest() {
      var e,
          i = !1,
          o = !0,
          t = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;"" != this.formFields.name ? (this.errorFields.name = "", e = !0) : this.errorFields.name = "Обязательное поле", "" != this.formFields.email && (t.test(this.formFields.email) ? (this.errorFields.email = "", o = !0) : (this.errorFields.email = "Введите корректный email", o = !1)), "" != this.formFields.phone ? (this.errorFields.phone = "", i = !0) : this.errorFields.phone = "Обязательное поле", e && i && o && this.$http.post("http://bus-razborka.com.ua", this.formFields, { emulateJSON: !0 }).then(function (e) {
        var i = this;console.log(e), this.ok = !0, setTimeout(function () {
          i.ok = !1, i.show = "";
        }, 1500);
      }, function (e) {
        console.log(e);
      });
    } } });$(document).ready(function () {
  $(".accordion-tabs-minimal").each(function (e) {
    $(this).children(".tab-header-and-content").first().children(".tab-link").addClass("is-active").next().addClass("is-open").show(), $(this).children(".tab-header-and-content").first().children(".tab-link").children(".triangle").addClass("triangle-active").show();
  }), $(".accordion-tabs-minimal").on("click", "li > a.tab-link", function (e) {
    if ($(this).hasClass("is-active")) e.preventDefault();else {
      e.preventDefault();var i = $(this).closest(".accordion-tabs-minimal");i.find(".is-open").removeClass("is-open").hide(), i.find(".triangle-active").removeClass(".triangle-active").hide(), $(this).next().toggleClass("is-open").toggle(), i.find(".is-active").removeClass("is-active"), $(this).addClass("is-active"), $(this).children(".triangle-active").hide(), $(this).children(".triangle").addClass("triangle-active").show();
    }
  }), $(".fancybox").fancybox({ openEffect: "none", closeEffect: "none", padding: 0, autoCenter: !0, closeClick: !0, nextClick: !0, autoWidth: !0 });
}), $(".call-back-link-prod").on("click", function (e) {
  $(".modal-state-prod").prop("checked", !0).change();
}), $(document).on("click", ".modal-fade-screen, .modal-close, .call", function () {
  $(".modal-state-prod:checked").prop("checked", !1).change();
});